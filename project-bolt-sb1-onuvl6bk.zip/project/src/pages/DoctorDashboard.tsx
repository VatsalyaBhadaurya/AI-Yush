import React from 'react';
import { Calendar, Users, FileText, Settings, Activity, ClipboardList } from 'lucide-react';

const DoctorDashboard = () => {
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Doctor Dashboard</h1>
          <p className="mt-2 text-gray-600">Welcome back, Dr. Sarah Wilson</p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <Users className="h-8 w-8 text-blue-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Patients</p>
                <p className="text-2xl font-semibold text-gray-900">248</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <Calendar className="h-8 w-8 text-green-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Appointments Today</p>
                <p className="text-2xl font-semibold text-gray-900">12</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <Activity className="h-8 w-8 text-purple-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Patient Recovery</p>
                <p className="text-2xl font-semibold text-gray-900">92%</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <FileText className="h-8 w-8 text-orange-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Reports Pending</p>
                <p className="text-2xl font-semibold text-gray-900">7</p>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Upcoming Appointments */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-xl font-semibold text-gray-900">Today's Appointments</h2>
              </div>
              <div className="p-6">
                <div className="space-y-6">
                  {[
                    {
                      name: 'John Doe',
                      time: '09:00 AM',
                      type: 'Follow-up',
                      status: 'Confirmed'
                    },
                    {
                      name: 'Emma Wilson',
                      time: '10:30 AM',
                      type: 'New Patient',
                      status: 'In Progress'
                    },
                    {
                      name: 'Michael Brown',
                      time: '02:00 PM',
                      type: 'Consultation',
                      status: 'Scheduled'
                    }
                  ].map((appointment, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center">
                        <div className="ml-4">
                          <p className="text-sm font-medium text-gray-900">{appointment.name}</p>
                          <p className="text-sm text-gray-500">{appointment.time} - {appointment.type}</p>
                        </div>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                        appointment.status === 'Confirmed' ? 'bg-green-100 text-green-800' :
                        appointment.status === 'In Progress' ? 'bg-blue-100 text-blue-800' :
                        'bg-yellow-100 text-yellow-800'
                      }`}>
                        {appointment.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow">
              <div className="p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Quick Actions</h2>
                <div className="space-y-4">
                  <button className="w-full flex items-center justify-center px-4 py-2 border border-blue-500 rounded-md shadow-sm text-sm font-medium text-blue-500 hover:bg-blue-50">
                    <Calendar className="mr-2 h-5 w-5" />
                    Schedule Appointment
                  </button>
                  <button className="w-full flex items-center justify-center px-4 py-2 border border-purple-500 rounded-md shadow-sm text-sm font-medium text-purple-500 hover:bg-purple-50">
                    <ClipboardList className="mr-2 h-5 w-5" />
                    Write Prescription
                  </button>
                  <button className="w-full flex items-center justify-center px-4 py-2 border border-green-500 rounded-md shadow-sm text-sm font-medium text-green-500 hover:bg-green-50">
                    <FileText className="mr-2 h-5 w-5" />
                    View Reports
                  </button>
                  <button className="w-full flex items-center justify-center px-4 py-2 border border-gray-500 rounded-md shadow-sm text-sm font-medium text-gray-500 hover:bg-gray-50">
                    <Settings className="mr-2 h-5 w-5" />
                    Settings
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DoctorDashboard;