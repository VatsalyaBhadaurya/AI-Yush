import React from 'react';
import { Calendar, Clock, FileText, Activity, User, Bell } from 'lucide-react';

const PatientDashboard = () => {
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Patient Dashboard</h1>
          <p className="mt-2 text-gray-600">Welcome back, James Wilson</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <Calendar className="h-8 w-8 text-blue-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Next Appointment</p>
                <p className="text-lg font-semibold text-gray-900">Mar 15, 2024</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <Activity className="h-8 w-8 text-green-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Health Status</p>
                <p className="text-lg font-semibold text-gray-900">Good</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <Bell className="h-8 w-8 text-purple-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Notifications</p>
                <p className="text-lg font-semibold text-gray-900">3 New</p>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Appointments and History */}
          <div className="lg:col-span-2 space-y-8">
            {/* Upcoming Appointments */}
            <div className="bg-white rounded-lg shadow">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-xl font-semibold text-gray-900">Upcoming Appointments</h2>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  {[
                    {
                      doctor: 'Dr. Sarah Wilson',
                      specialty: 'Cardiologist',
                      date: 'March 15, 2024',
                      time: '10:00 AM'
                    },
                    {
                      doctor: 'Dr. Michael Chen',
                      specialty: 'General Physician',
                      date: 'March 22, 2024',
                      time: '2:30 PM'
                    }
                  ].map((appointment, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-medium text-gray-900">{appointment.doctor}</p>
                        <p className="text-sm text-gray-500">{appointment.specialty}</p>
                        <div className="flex items-center mt-2 text-sm text-gray-500">
                          <Calendar className="h-4 w-4 mr-1" />
                          {appointment.date}
                          <Clock className="h-4 w-4 ml-4 mr-1" />
                          {appointment.time}
                        </div>
                      </div>
                      <button className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600">
                        Reschedule
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Medical History */}
            <div className="bg-white rounded-lg shadow">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-xl font-semibold text-gray-900">Recent Medical History</h2>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  {[
                    {
                      type: 'Consultation',
                      doctor: 'Dr. Sarah Wilson',
                      date: 'February 28, 2024',
                      notes: 'Regular checkup - Blood pressure normal'
                    },
                    {
                      type: 'Lab Test',
                      doctor: 'Dr. Michael Chen',
                      date: 'February 15, 2024',
                      notes: 'Blood work - Results pending'
                    }
                  ].map((record, index) => (
                    <div key={index} className="p-4 bg-gray-50 rounded-lg">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-medium text-gray-900">{record.type}</p>
                          <p className="text-sm text-gray-500">{record.doctor}</p>
                        </div>
                        <span className="text-sm text-gray-500">{record.date}</span>
                      </div>
                      <p className="mt-2 text-sm text-gray-600">{record.notes}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Side Panel */}
          <div className="space-y-8">
            {/* Profile Summary */}
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center mb-4">
                <User className="h-12 w-12 text-gray-400 bg-gray-100 rounded-full p-2" />
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-gray-900">James Wilson</h3>
                  <p className="text-sm text-gray-500">Patient ID: P-12345</p>
                </div>
              </div>
              <div className="space-y-3">
                <div>
                  <p className="text-sm font-medium text-gray-500">Age</p>
                  <p className="text-sm text-gray-900">32 years</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Blood Type</p>
                  <p className="text-sm text-gray-900">O+</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Primary Doctor</p>
                  <p className="text-sm text-gray-900">Dr. Sarah Wilson</p>
                </div>
              </div>
              <button className="mt-4 w-full flex items-center justify-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50">
                View Full Profile
              </button>
            </div>

            {/* Quick Actions */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Quick Actions</h3>
              <div className="space-y-4">
                <button className="w-full flex items-center justify-center px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600">
                  <Calendar className="mr-2 h-5 w-5" />
                  Book Appointment
                </button>
                <button className="w-full flex items-center justify-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50">
                  <FileText className="mr-2 h-5 w-5" />
                  View Medical Records
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PatientDashboard;